//package com.iamneo.security.service;
//
//import java.util.Optional;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.iamneo.security.entity.advisoraccount;
//import com.iamneo.security.repository.advisorRepository;
//@Service
//public class advisorservice {
//	@Autowired
//	advisorRepository repository;
//	public Optional<advisoraccount>getStudent(String mailid){
//		return repository.findById(mailid);
//	}
//
//}
