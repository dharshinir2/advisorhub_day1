import React ,{useState} from "react";
import { Link } from "react-router-dom";
import './new.css';
function New(){
  
  return(
    <div>
       
        
        
        <div className="background">
          <div className="a" />
  
        </div>
        <form>
        <h3>Advisor Account Creation</h3>
          

          <label htmlFor="area">Area of Interest</label>
          <input type="text" placeholder="Enter your area of interest" id="area" required />
          <br></br>

          <label htmlFor="eq">Educational Qualification</label>
          <input type="text" placeholder="Enter your educational qualification" id="eq" required />
          <br></br>

          <label htmlFor="es">Experience</label>
          <input type="text" placeholder="Enter your Experience" id="es" required />
          <br></br>
          <label htmlFor="l">Language</label>
          <input type="text" placeholder="Enter your preferred Language" id="l" required />
          <br></br>
          <label htmlFor="lo">Location</label>
          <input type="text" placeholder="Enter your location" id="lo" required />
          <br></br>

          

          <input type="submit"/>
          {/* <  <Link to='/'>Create Your Account</Link>> */}
          <button> <Link to='/'>Create Your Account</Link></button>
        </form>
      </div>
  )
}
export default New;
