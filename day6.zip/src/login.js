// import React from "react";
// import './login.css';
// import { Link } from "react-router-dom";
// function Login(){
//   return(
//     <div className="bg"> 
//         <div className="background">
//           <div className="a" />
  
//         </div>
//         <form>
//           <h3>Login Here</h3>
//           <label htmlFor="username">Username</label>
//           <input type="text" placeholder="Email or Phone" id="username" required/>
//           <label htmlFor="password">Password</label>
//           <input type="password" placeholder="Password" id="password" required/>
//           <br></br>
//           <br></br>
//           <br></br>
          
          

//           <button><Link to='/home'>Submit</Link></button>
//           <button><Link to='/newuser'>New User?</Link></button>
          
//         </form>
//       </div>
//   )
// }
// export default Login;
import React from 'react';
import { connect } from 'react-redux';
import { useState } from 'react';

import { setUsername, setPassword } from './action';
import './login.css';
import { Link } from 'react-router-dom';

function Login({ username, password, setUsername, setPassword }) {
  const handleUsernameChange = (event) => {
    setUsername(event.target.value);
  };
  const handleShowAlert = () => {
    alert("Welcome "+username);
  };
 
 
  const handlePasswordChange = (event) => {
    setPassword(event.target.value);
  };

  return (
    <div className="bg">
      
      <div className="background">
        <div className="a" />
      </div>
      <form>
        <h3>Login Here</h3>
        <label htmlFor="username">Username</label>
        <input
          type="text"
          placeholder="username"
          id="username"
          value={username}
          onChange={handleUsernameChange}
          required

        />
        <label htmlFor="password">Password</label>
        <input
          type="password"
          placeholder="Password"
          id="password"
          value={password}
          onChange={handlePasswordChange}
          required
        />
        <br></br>
        <br></br>
        <br></br>
        <button onClick={handleShowAlert}>
          <Link to="/home">Submit</Link>
        </button>
        <button>
          <Link to="/newuser">New User?</Link>
        </button>
      </form>
    </div>
  );
}

const mapStateToProps = (state) => ({
  username: state.username,
  password: state.password,
});

const mapDispatchToProps = {
  setUsername,
  setPassword,
};

export default connect(mapStateToProps, mapDispatchToProps)(Login);