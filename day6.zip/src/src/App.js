
import './App.css';
import Home from './home';
import Login from './login';
import New from './newuser';
import { Route,Routes } from 'react-router';
import Second from './second';
import About from './about';
import Inbox from './inbox';
import Profile from './profile';
import Advisors from './advisors';



function App() {
  return (
    <Routes>
      <Route path='/' element={<Login/>}/>
      <Route path='/newaccount' element={<New/>}/>
      <Route path='/newuser' element={<Second/>}/>
      <Route path='/home' element={<Home/>}/>
      <Route path='/home/about' element={<About/>}/>
      <Route path='home/inbox' element={<Inbox/>}/>
      <Route path='home/profile' element={<Profile/>}/>
      <Route path='/edit' element={<Second/>}/>
      <Route path='/home/advisors' element={<Advisors/>}/>
      
    </Routes>
  );
}

export default App;
