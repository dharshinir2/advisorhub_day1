import React, { useState } from 'react';
import './navbar.css';
import { Link } from "react-router-dom";
import SidePanel from './sidepanel';
import './sidepanel.css';

const Navbar = () => {
  const [searchTerm, setSearchTerm] = useState('');

  const handleSearch = (term) => {
    setSearchTerm(term);
  };
  const [isOpen, setIsOpen] = useState(false);

  const openNav = () => {
    setIsOpen(true);
  };

  const closeNav = () => {
    setIsOpen(false);
  };
  
    const handleChange = (event) => {
      handleSearch(event.target.value);
    };
  

  return (
    <>
      <div id="menu" className={`sidenav ${isOpen ? 'open' : ''}`}>
        <a href="javascript:void(0)" className="closebtn" onClick={closeNav}>
          ×
        </a>
        <ul>
          <li>
            <Link to="./about"><a href="#">About</a></Link>
          </li>
         
          <li>
            <a href="/home/advisors">Advisors</a>
          </li>
          <li>
            <a href="/history">History</a>
          </li>
        </ul>
      </div>

      <div id="main">...</div>

      <div className="topnav">
        <input className='search' type="text" placeholder="Search.."  onChange={handleChange}/>
        <ul>
       
        <li className='menu'>
          {/* <span onClick={openNav}>&#9776</span> */}
          <button className="openbtn" onClick={openNav}>☰</button>
        </li>
        
          <li>
          <Link to="./profile"><a>Profile</a></Link>
          </li>
          <li>
            <Link to="./inbox"><a>Inbox</a></Link>
          </li>
          <li>
          <Link to="./"><a>Home</a></Link>
          </li>
        </ul>
      </div>
    
    </>
  );
};

export default Navbar;

//navbar in react?