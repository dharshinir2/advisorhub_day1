function Advisorprofile(){
    return(
        <>
        
          <>
  <link
    // href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css"
    rel="stylesheet"
  />
  <div className="container bootstrap snippets bootdey">
    <div className="row">
      <div className="profile-nav col-md-3">
        <div className="panel">
          <div className="user-heading round">
            <h1 style={{fontSize:"40px"}}>Charles Leclerc</h1>
          
      </div>
      
        <div className="panel">
          <footer className="panel-footer">
            {/* <ul className="nav nav-pills">
              
              <li>
               
              </li>
              <li>
                <a href="#">
                  <i className=" fa fa-film" />
                </a>
              </li>
              <li>
          
                <a href="#">
                  <i className="fa fa-microphone" />
                </a>
              </li>
            </ul> */}
          </footer>
        </div>
        <div className="panel">
          <div className="bio-graph-heading">
           ADVISOR @AdvisorHUB
          </div>
          <div className="panel-body bio-graph-info">
            <h1 style={{color:"bla"}}>Profile</h1>
            <div className="row">
            <div className="bio-row">
                <p>
                  <span>Advisor Id </span>: A00245
                </p>
              </div>
              <div className="bio-row">
                <p>
                  <span>Expertise </span>: Software Development
                </p>
              </div>
              
              <div className="bio-row">
                <p>
                  <span>Country </span>: India
                </p>
              </div>
              <div className="bio-row">
                <p>
                  <span>Occupation </span>: UI Designer
                </p>
              </div>
              <div className="bio-row">
                <p>
                  <span>Experience </span>: 5 years
                </p>
              </div>
              <div className="bio-row">
                <p>
                  <span>Email </span>: jsmith@flatlab.com
                </p>
              </div>
              <div className="bio-row">
                <p>
                  <span>Phone </span>: 9363161145
                </p>
              </div>
              <div className="bio-row">
                <p>
                  <span>Language </span>: English
                </p>
              </div>
              <div className="bio-row">
                <p>
                  <span>Rating</span>:4.25/5
                </p>
              </div>
            </div>
            </div>

          
        
          </div>
        </div>
        
      </div>
    </div>
    <div className="sa">
<ul >
  <li className="bb">
    <a href="/contact">
      {" "}
      <i style={{color: "black"}} /> Contact
    </a>
  </li>
 
</ul>
</div>
  </div>
</>
        </>
    )

}
export default Advisorprofile;