import { Link } from "react-router-dom";
function Search(){
    return(
        <></>
    )
}
export default Search;