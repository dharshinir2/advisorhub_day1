import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';


function Feedback(){

  const navigate = useNavigate();
  
  const [email, setMailid] = useState('');
  const [feedback, setFeedback] = useState('');
  
  const [showAlert, setShowAlert] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const token=localStorage.getItem('token');
    console.log(token);
    try {
      const response = await axios.post('http://localhost:8181/api/v1/users/addUserFeedback', {
        email,
        feedback,
      },
      {
        headers:{
          "cache-control":'no-cache',
          "Authorization":`Bearer ${token}`,
        }
      }
      );
      if (response.status === 200) {


        setMailid('');
        setFeedback('');
        navigate('/home');
      }

     
      
      
    } catch (error) {
      // Clear the input fields after successful submission.
     
    }
  };

  return (
    <div className="bg">
      <div className="background">
        <div className="a" />
      </div>
      <form >
        <h3>Feedback form</h3>
        <label htmlFor="email">Email</label>
        <input
          type="email"
          placeholder="Email"
          id="email"
          value={email}
          onChange={(e) => setMailid(e.target.value)}
       
          required
        />
       
        <label htmlFor="feedback">Feedback</label>
        <input
          type="text"
          placeholder="feedback"
          id="feedback"
          value={feedback}
            onChange={(e) => setFeedback(e.target.value)}
            
          required
        />
        <br />
        <br />
        <br />
        <button type="submit" className="btn-primary1"  onClick={handleSubmit}>
            Update
          </button>
        
        
      </form>
    </div>
  );
}



export default Feedback;